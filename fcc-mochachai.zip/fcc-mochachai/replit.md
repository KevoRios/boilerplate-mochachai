# Quality Assurance with Chai - Testing Application

## Overview
This is a Node.js/Express web application designed as a boilerplate for learning Quality Assurance and testing with the Chai assertion library. It demonstrates unit testing, integration testing with chai-http, and headless browser testing with Zombie.js.

**Current State**: Configured for Replit environment (November 12, 2025)

## Purpose
- Educational tool for learning Chai testing framework
- Demonstrates various assertion methods (isNull, isDefined, equal, deepEqual, etc.)
- Shows functional testing with HTTP requests and headless browser interactions
- Interactive web interface for testing Famous Italian Explorers API

## Recent Changes
- **2025-11-12**: Initial Replit configuration
  - Changed server port from 3000 to 5000 for Replit compatibility
  - Configured server to bind to 0.0.0.0 for public access
  - Set up workflow for running the application

## Project Architecture

### Structure
```
├── server.js              # Express server and API endpoints
├── test-runner.js         # Mocha test orchestration
├── assertion-analyser.js  # Parses assertion bodies from tests
├── views/
│   └── index.html        # Frontend UI
├── public/
│   ├── client.js         # Client-side AJAX logic
│   └── style.css         # Styling
└── tests/
    ├── 1_unit-tests.js   # Chai unit tests
    └── 2_functional-tests.js # Integration and browser tests
```

### Key Technologies
- **Backend**: Express.js on Node.js
- **Testing**: Mocha, Chai, chai-http, Zombie.js
- **Port**: 5000 (Replit standard for web preview)
- **Host**: 0.0.0.0 (allows Replit proxy access)

### API Endpoints
- `GET /` - Serves main HTML page
- `GET /hello?name=<name>` - Returns greeting text
- `PUT /travellers` - Returns explorer info based on surname
- `GET /_api/get-tests` - Returns test results (CORS enabled)

## Dependencies
- express: 4.17.1
- chai: 4.3.4
- mocha: 9.0.3
- chai-http: 4.3.0
- zombie: 6.1.4
- body-parser: 1.19.0
- cors: 2.8.5

## User Preferences
None specified yet.
